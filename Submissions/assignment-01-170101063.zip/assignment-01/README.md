# assignment-01

### Run
```bash
sudo apt-get install freeglut3-dev
make
```
 - Left mouse click changes colour of triangles
 - Right mouse button switches between FILL and OUTLINE for triangles

Made by Shivam Bansal
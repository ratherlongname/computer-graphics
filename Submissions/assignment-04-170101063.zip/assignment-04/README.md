# assignment-04

Rotate and zoom 3D model using mouse

### Run
```bash
sudo apt-get install freeglut3-dev
make
```
 - Left click drag to rotate model
 - Scroll wheel up/down to zoom in/out
 - Right click to switch between fill and outline mode

Made by Shivam Bansal